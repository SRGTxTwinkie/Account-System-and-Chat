$stdout.sync = true

def cClear
  print "                                                                    \r"
end

print "Hello there \r"
sleep(3)
cClear()
print "F \r"
